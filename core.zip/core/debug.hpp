#include <chrono>

auto get_current_time() {
    return std::chrono::system_clock::now();
}

template < typename Fn > auto get_fn_cost(Fn fn) {
    auto tp1 = get_current_time();
    fn();
    return std::chrono::duration_cast< std::chrono::milliseconds >(get_current_time() - tp1)
        .count();
}