#pragma once
#include <future>
#include <thread>
template < typename R, typename Fn > std::future< R > start_detached_future(Fn func) {
    std::promise< R > pro;
    std::future< R > fut = pro.get_future();
    std::thread([func](std::promise< R > p) { p.set_value(func()); }, std::move(pro)).detach();
    return fut;
}