#pragma once
#include "core/expected.hpp"

#include <string>

struct Error {
    enum class Level : int { kInfo, kWarn, kError, kCritical };
    Level level;
    std::string err_info;
};

template < typename T > using Result = tl::expected< T, Error >;

template < typename T > inline Result< T > make_error(Error::Level level, std::string error) {
    return tl::make_unexpected(Error{level, error});
}