#ifdef let
#undef let
#endif

#ifdef mut
#undef mut
#endif

#define let const auto
#define mut auto