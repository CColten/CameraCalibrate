#include <fstream>

inline bool is_file_exists(const std::string& name) {
    std::ifstream f(name.c_str());
    return f.good();
}